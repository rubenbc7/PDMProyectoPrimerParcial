//
//  ViewController.swift
//  Constrains2ruben
//
//  Created by Alumno on 08/09/21.
//  Copyright © 2021 Ruben Borbolla. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var playerFondo = AVAudioPlayer()
    var playerAnimal = AVAudioPlayer()
    
    let urlFondo = Bundle.main.url(forResource: "FondoMusica", withExtension: "mp3")
    let urlPerro = Bundle.main.url(forResource: "Dog", withExtension: "mp3")
    let urlGato = Bundle.main.url(forResource: "Cat", withExtension: "mp3")
    let urlRata = Bundle.main.url(forResource: "Rat", withExtension: "mp3")
    
    let GifGato = [
           UIImage(named: "Michi1")!,
           UIImage(named: "Michi2")!,
           UIImage(named: "Michi3")!,
           UIImage(named: "Michi4")!,
           UIImage(named: "Michi5")!

       ]
    let GifPerro = [
           UIImage(named: "Perro1")!,
           UIImage(named: "Perro2")!,
           UIImage(named: "Perro3")!,
           UIImage(named: "Perro4")!,
           UIImage(named: "Perro5")!

       ]
    let GifRata = [
           UIImage(named: "Rata1")!,
           UIImage(named: "Rata2")!,
           UIImage(named: "Rata3")!,
           UIImage(named: "Rata4")!,
           UIImage(named: "Rata5")!

       ]
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var GifGrande: UIImageView!
    @IBOutlet weak var imgMichi: UIImageView!
    @IBOutlet weak var imgPerro: UIImageView!
    @IBOutlet weak var imgRata: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        do{
                    //try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                    try AVAudioSession.sharedInstance().setActive(true)
                    playerFondo = try AVAudioPlayer(contentsOf: urlFondo!, fileTypeHint: AVFileType.mp3.rawValue)
                    playerFondo.numberOfLoops = -1
                    playerFondo.volume = 0.5
                    playerFondo.play()
                } catch let error {
                    print(error.localizedDescription)
                }
                // Do any additional setup after loading the view.
                imgMichi.animationImages = GifGato
                imgMichi.animationDuration = 0.2
                imgMichi.startAnimating()
                
                imgPerro.animationImages = GifRata
                imgPerro.animationDuration = 0.2
                imgPerro.startAnimating()
                
                imgRata.animationImages = GifPerro
                imgRata.animationDuration = 0.2
                imgRata.startAnimating()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func doTapMichi(_ sender: Any) {
        lblNombre.text = "Cat"
                GifGrande.animationImages = GifGato
                GifGrande.animationDuration = 0.2
                GifGrande.startAnimating()
                
                do{
                    playerAnimal = try AVAudioPlayer(contentsOf: urlGato!, fileTypeHint: AVFileType.mp3.rawValue)
                    playerAnimal.play()
                } catch let error {
                    print(error.localizedDescription)
                }
    }
    
    @IBAction func doTapRata(_ sender: Any) {
    
    lblNombre.text = "Dog"
            GifGrande.animationImages = GifPerro
            GifGrande.animationDuration = 0.2
            GifGrande.startAnimating()
            
            do{
                playerAnimal = try AVAudioPlayer(contentsOf: urlPerro!, fileTypeHint: AVFileType.mp3.rawValue)
                playerAnimal.play()
            } catch let error {
                print(error.localizedDescription)
            }
    

    }
    @IBAction func doTapPerro(_ sender: Any) {
        lblNombre.text = "Rat"
                GifGrande.animationImages = GifRata
                GifGrande.animationDuration = 0.2
                GifGrande.startAnimating()
                
                do{
                    playerAnimal = try AVAudioPlayer(contentsOf: urlRata!, fileTypeHint: AVFileType.mp3.rawValue)
                    playerAnimal.play()
                } catch let error {
                    print(error.localizedDescription)
                }
    }
    
}
